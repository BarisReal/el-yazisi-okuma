Predicting Handwritten Digits GUI
==============================

https://www.youtube.com/watch?v=pRM2cF4lmUA (13k Views)

What Is This?
-------------

<img width="314" alt="Ekran Resmi 2022-10-15 09 07 25" src="https://user-images.githubusercontent.com/54773283/195971831-455f90b3-de3b-4ccf-a1e9-0c01bf38c577.png"> <img width="352" alt="Ekran Resmi 2022-10-15 09 07 03" src="https://user-images.githubusercontent.com/54773283/195971833-843e4f00-1281-4a38-af88-7e76e5e0dcdd.png">

Artificial intelligence project for beginners that predicts drawed numbers that can provide insight into how machine learning models work.

How To Use This
---------------

1. Install required libraries from requirements.txt
2. Run test.py Python file.
3. Enjoy!
